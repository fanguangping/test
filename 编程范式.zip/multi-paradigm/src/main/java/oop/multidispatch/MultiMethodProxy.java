package oop.multidispatch;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by fangp on 2018/6/4.
 */
public class MultiMethodProxy implements InvocationHandler {
	private Object multiMethodsImpl;

	public MultiMethodProxy(Object multiMethodsImpl) {
		this.multiMethodsImpl = multiMethodsImpl;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (Object.class.equals(method.getDeclaringClass())) {
			try {
				return method.invoke(this, args);
			}
			catch (Throwable t) {
				t.printStackTrace();
			}
		}
		else {
			return dispatch(method, args);
		}
		return null;
	}

	private Object dispatch(Method method, Object[] args) throws Exception {
		if (multiMethodsImpl == null) {
			throw new Exception("impl method is null");
		}
		Method[] methods = multiMethodsImpl.getClass().getDeclaredMethods();
		for (Method impl : methods) {
		    if (match(method, args, impl)) {
		        return impl.invoke(multiMethodsImpl, args);
            }
        }
		return null;
	}

	private boolean match(Method method, Object[] args, Method impl) {
		if (!impl.getName().equals(method.getName())) {
			return false;
		}
		Class<?>[] types = impl.getParameterTypes();
		if (args.length != types.length) {
			return false;
		}
		for (int i = 0; i < args.length; i++) {
		    if (args[i] == null) {
		        return false;
            }
            if (!args[i].getClass().isAssignableFrom(types[i])) {
		        return false;
            }
		}
		return true;
	}
}
