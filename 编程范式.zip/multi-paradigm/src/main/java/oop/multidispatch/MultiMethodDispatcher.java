package oop.multidispatch;

import java.lang.reflect.Proxy;

/**
 * Created by fangp on 2018/6/4.
 */
public class MultiMethodDispatcher {

	public static <T> T proxy(Class<T> cls, Object impl) {
		MultiMethodProxy invocationHandler = new MultiMethodProxy(impl);
		Object newProxyInstance = Proxy.newProxyInstance(cls.getClassLoader(), new Class[] { cls }, invocationHandler);
		return (T) newProxyInstance;
	}

}
