package aop;

import clojure.lang.RT;
import clojure.lang.Var;

import java.io.IOException;

/**
 * Created by fangp on 2018/6/4.
 */
public class ClojureAop {
    //Prevent script reloads.
    static { //Did you know you could do this?
        try {
            RT.loadResourceScript("aop.clj");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static Var fn = RT.var("demo.aop", "my-logged-calculation");

    public static void test() {
        System.out.println(fn.invoke());
    }

    //https://github.com/markbastian/java-calls-clojure
    public static void main(String[] args) throws Exception {
        test();
    }
}
