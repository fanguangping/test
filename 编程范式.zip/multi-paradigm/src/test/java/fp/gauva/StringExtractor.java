package fp.gauva;

import java.util.List;

import com.google.common.base.Joiner;
import org.junit.Assert;
import org.junit.Test;

import com.google.common.base.Predicate;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.common.primitives.Doubles;

/**
 * Created by fangp on 2018/6/1.
 */
public class StringExtractor {

	@Test
	public void test() {
	    String source = "Abc,123.456,sfd,你好,876,-2.3,The end";

		List<String> list = Splitter.on(",").omitEmptyStrings().splitToList(source);
		Iterable<String> stringList = Iterables.filter(list, new Predicate<String>() {
			@Override
			public boolean apply(String s) {
				return Doubles.tryParse(s) == null;
			}
		});
        String output = Joiner.on(",").join(stringList);

		Assert.assertEquals("Abc,sfd,你好,The end", output);
	}
}
