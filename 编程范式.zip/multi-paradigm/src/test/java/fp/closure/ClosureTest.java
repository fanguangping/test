package fp.closure;

import java.io.StringReader;

import org.junit.Test;

import jsint.Evaluator;
import jsint.InputPort;

/**
 * Created by fangp on 2018/6/1.
 */
public class ClosureTest {

	@Test
	public void test() throws Exception {
		Evaluator evaluator = new Evaluator();
		System.out.println(eval(evaluator, "(define (addx x) (lambda (y) (+ y x)))"));
		System.out.println(eval(evaluator, "(define add8 (addx 8))"));
		System.out.println(eval(evaluator, "(define add9 (addx 9))"));
		System.out.println(eval(evaluator, "(add8 100)"));
		System.out.println(eval(evaluator, "(add9 100)"));
	}

	public String eval(Evaluator evaluator, String input) {
		InputPort inputPort = new InputPort(new StringReader(input));
		Object output = evaluator.eval(inputPort.read());
		return output.toString();
	}
}
