package fp.qsort;

import java.io.IOException;

import clojure.lang.RT;
import clojure.lang.Var;

/**
 * Created by fangp on 2018/6/4.
 */
public class QuickSort {
	//Prevent script reloads.
	static { //Did you know you could do this?
		try {
			RT.loadResourceScript("qsort.clj");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static Var fn = RT.var("demo.qsort", "qsort");

	public static void test() {
		System.out.println(fn.invoke());
	}

	//https://github.com/markbastian/java-calls-clojure
	public static void main(String[] args) throws Exception {
		test();
	}
}
