package lp;

import java.net.URL;

import org.junit.Test;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import alice.tuprolog.Prolog;
import alice.tuprolog.SolveInfo;
import alice.tuprolog.Theory;

/**
 * Created by fangp on 2018/5/31.
 */
public class ZebraSolver {

	@Test
	public void solveProblem() throws Exception {
		URL url = Resources.getResource("zebra.pl");
		String text = Resources.toString(url, Charsets.UTF_8);

		Prolog prolog = new Prolog();
		prolog.setTheory(new Theory(text));
		SolveInfo info = prolog.solve("all_houses(A).");
		System.out.println(info.getSolution());
	}

}
