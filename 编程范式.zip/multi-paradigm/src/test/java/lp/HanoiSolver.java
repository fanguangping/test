package lp;

import alice.tuprolog.Prolog;
import alice.tuprolog.SolveInfo;
import alice.tuprolog.Theory;
import alice.tuprolog.event.OutputEvent;
import alice.tuprolog.event.OutputListener;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import org.junit.Test;

import java.net.URL;

/**
 * Created by fangp on 2018/6/5.
 */
public class HanoiSolver {

    @Test
    public void solveProblem() throws Exception {
        URL url = Resources.getResource("hanoi.pl");
        String text = Resources.toString(url, Charsets.UTF_8);

        Prolog prolog = new Prolog();
        prolog.setTheory(new Theory(text));
        prolog.addOutputListener(new OutputListener() {
            @Override
            public void onOutput(OutputEvent e) {
                System.out.print(e.getMsg());
            }
        });
        prolog.solve("hanoi(4).");
    }
}
