package oop.polymorphism;

import org.junit.Test;

/**
 * Created by fangp on 2018/6/1.
 */
public class PolyDemo {
    interface Animal {
        void 叫();
    }

    class Cat implements Animal {
        public void 叫() {
            System.out.println("喵喵");
        }
    }

    class Dog implements Animal {
        public void 叫() {
            System.out.println("汪汪");
        }
    }

    @Test
    public void test() {
        Animal animal = new Cat();
        animal.叫();
        animal = new Dog();
        animal.叫();
    }
}
