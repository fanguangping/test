package oop.multidispatch;

import org.junit.Test;

/**
 * Created by fangp on 2018/6/1.
 */
public class MultiMethodTest {

	class Shape {
	}

	class Circle extends Shape {
	}

	class Rectangle extends Shape {
	}

	class Triangle extends Shape {
	}

	public interface Intersectable {
		void intersect(Shape x, Shape y);
	}

	public class IntersectImpl {
		void intersect(Circle x, Circle y) {
			System.out.println("Circle x, Circle y");
		}

		void intersect(Circle x, Rectangle y) {
			System.out.println("Circle x, Rectangle y");
		}

		void intersect(Circle x, Triangle y) {
			System.out.println("Circle x, Triangle y");
		}

		void intersect(Rectangle x, Rectangle y) {
			System.out.println("Rectangle x, Triangle y");
		}
	}

	@Test
	public void test() {
		Intersectable invoker = MultiMethodDispatcher.proxy(Intersectable.class, new IntersectImpl());
		invoker.intersect(new Circle(), new Circle());
		invoker.intersect(new Circle(), new Rectangle());
		invoker.intersect(new Circle(), new Triangle());
		invoker.intersect(new Rectangle(), new Triangle());
		invoker.intersect(new Rectangle(), new Rectangle());
	}
}
