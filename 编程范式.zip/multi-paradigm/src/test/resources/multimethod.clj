(ns demo.multimethod)

(derive ::circle ::shape)
(derive ::rectangle ::shape)
(derive ::triangle ::shape)

(defmulti intersect (fn [a b] [a b]))
(defmethod intersect [::circle ::circle] [x y] "intersect circle circle")
(defmethod intersect [::circle ::rectangle] [x y] "intersect circle rectangle")
(defmethod intersect [::circle ::triangle] [x y] "intersect circle triangle")
(defmethod intersect [::rectangle ::triangle] [x y] "intersect rectangle triangle")

(defn myintersect [] (intersect ::circle ::rectangle))
