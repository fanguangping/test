(ns demo.qsort)

(defn quick-sort [[pivot & coll]]
  (when pivot
    (concat (quick-sort (filter #(< % pivot) coll))
            [pivot]
            (quick-sort (filter #(>= % pivot) coll)))))

(defn qsort [] (seq (quick-sort [3, 1, 4, 5, 2, 8])))
